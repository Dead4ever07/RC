
#include "debug.h"

void printError(const char* funcName, const char* errorMessage){
    printf("Error %s - %s", funcName, errorMessage);
}
